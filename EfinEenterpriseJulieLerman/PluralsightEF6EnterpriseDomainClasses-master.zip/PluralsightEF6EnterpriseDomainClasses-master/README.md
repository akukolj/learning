# PluralsightEF6EnterpriseDomainClasses
This is a holding place where I'll put the folder that contains some simple domain classes for an upcoming Pluralsight course.
